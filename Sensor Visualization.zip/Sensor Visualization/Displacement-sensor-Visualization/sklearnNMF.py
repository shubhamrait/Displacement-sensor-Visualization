import pandas
import numpy as np
from sklearn.decomposition import NMF
if(__name__ == '__main__'):
	x=pandas.io.parsers.read_csv(open("INPUT.csv",newline=''),delimiter=',').values
	minimum=[0][0]
	for temp in x:
		for tmp in temp:
			if(tmp<minimum):
				minimum = tmp
	print("Is minumum"+str(minimum))
	for a in range(0,len(x)):
		for b in range(0,len(x[0])):
			x[a][b] = x[a][b] + abs(minimum)
	for temp in x:
		print(temp)
	Nmf = NMF(n_components=2,solver='mu',init='nndsvda',max_iter=10000000000)
	Y=Nmf.fit_transform(x)
	np.savetxt('sklearnNMF.csv', Y, delimiter=',')
	